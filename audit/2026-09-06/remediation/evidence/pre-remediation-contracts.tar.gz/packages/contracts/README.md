# Protocol contracts

The contracts implement the onchain portion of Conditional Stocks v1. Read [`docs/architecture/protocol-v1.md`](../../docs/architecture/protocol-v1.md) and [`SECURITY.md`](../../SECURITY.md) before changing them.

## Local verification

```bash
forge fmt --check
forge build --sizes
forge test
forge coverage --ir-minimum --report summary
```

The suite deploys the bytecode from the pinned `@gnosis.pm/conditional-tokens-contracts@1.0.3` artifact. It does not replace CTF with a simplified mock.

Production collateral must be an exact, independently verified 18-decimal ERC-20 supported by that pinned CTF. In particular, its `transfer` and `transferFrom` calls must return a boolean: the legacy CTF rejects empty-return tokens. Tests prove false-return tokens are rejected and empty-return failures roll back fills without trapping order escrow.

Compiler settings are deliberately fixed in `foundry.toml`: Solidity 0.8.30, `paris`, IR pipeline, 7,500 optimizer runs, and metadata hash disabled. All production runtime bytecodes must remain below EIP-170. `.gas-snapshot` records the current regression baseline.

## Administrative scripts

```bash
bun run deploy:v1
bun run market:create
bun run market:resolve
```

Market creation and resolution default to simulation-only and print exact calldata. Broadcasting requires the explicit `SUBMIT_ADMIN_ACTION=true` environment flag. Neither script fetches Polymarket state or automates an admin decision.
