import { encodeFunctionData, getAddress } from "viem";

import {
  createChainClients,
  createPublicChainClient,
  environmentAddress,
  environmentBigInt,
  environmentHex32,
  loadArtifact,
  requiredEnvironment,
  writeOutput,
} from "./lib.ts";

const controller = environmentAddress("RESOLUTION_CONTROLLER_ADDRESS");
const adminCaller = environmentAddress("ADMIN_CALLER_ADDRESS");
const marketId = environmentHex32("MARKET_ID");
const yesPayout = environmentBigInt("YES_PAYOUT");
const noPayout = environmentBigInt("NO_PAYOUT");
const payoutDenominator = environmentBigInt("PAYOUT_DENOMINATOR");
const evidenceHash = environmentHex32("EVIDENCE_HASH");
const evidenceUri = requiredEnvironment("EVIDENCE_URI");
const validVector =
  (yesPayout === 1n && noPayout === 0n && payoutDenominator === 1n) ||
  (yesPayout === 0n && noPayout === 1n && payoutDenominator === 1n) ||
  (yesPayout === 1n && noPayout === 1n && payoutDenominator === 2n);
if (!validVector) throw new Error("Resolution vector must be YES, NO, or invalid 50/50");

const { chainId, publicClient } = await createPublicChainClient();
const artifact = await loadArtifact("ManualResolutionController");
const args = [marketId, yesPayout, noPayout, payoutDenominator, evidenceHash, evidenceUri] as const;
const calldata = encodeFunctionData({
  abi: artifact.abi,
  args,
  functionName: "resolveMarket",
} as never);

await publicClient.simulateContract({
  abi: artifact.abi,
  account: adminCaller,
  address: controller,
  args,
  functionName: "resolveMarket",
} as never);

if (Bun.env.SUBMIT_ADMIN_ACTION !== "true") {
  writeOutput({
    action: "resolveMarket",
    calldata,
    chainId,
    evidenceHash,
    evidenceUri,
    from: adminCaller,
    marketId,
    mode: "simulation-only",
    payout: {
      denominator: payoutDenominator.toString(),
      no: noPayout.toString(),
      yes: yesPayout.toString(),
    },
    to: controller,
  });
} else {
  const { account, chain, walletClient } = await createChainClients("ADMIN_PRIVATE_KEY");
  if (getAddress(account.address) !== adminCaller) {
    throw new Error("ADMIN_PRIVATE_KEY does not match ADMIN_CALLER_ADDRESS");
  }
  const hash = await walletClient.writeContract({
    abi: artifact.abi,
    account,
    address: controller,
    args,
    chain,
    functionName: "resolveMarket",
  } as never);
  writeOutput({ action: "resolveMarket", chainId, marketId, transactionHash: hash });
}
