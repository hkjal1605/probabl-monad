import { mkdir } from "node:fs/promises";
import { resolve } from "node:path";
import { type Abi, type Address, getAddress, type Hash, type Hex, keccak256 } from "viem";

import {
  assertContract,
  createChainClients,
  environmentAddress,
  loadArtifact,
  loadConditionalTokensArtifact,
  writeOutput,
} from "./lib.ts";

interface DeploymentRecord {
  address: Address;
  blockNumber?: string;
  bytecodeHash?: Hex;
  transactionHash?: Hash;
}

const { account, chain, chainId, publicClient, walletClient } =
  await createChainClients("DEPLOYER_PRIVATE_KEY");
const initialAdmin = environmentAddress("INITIAL_ADMIN");
if (initialAdmin !== getAddress(account.address)) {
  throw new Error("INITIAL_ADMIN must equal the deployment account for atomic configuration");
}
const finalAdmin = environmentAddress("FINAL_ADMIN");
const roleAddresses = {
  guardian: environmentAddress("GUARDIAN"),
  marketAdmin: environmentAddress("MARKET_ADMIN"),
  matcher: environmentAddress("MATCHER"),
  resolutionAdmin: environmentAddress("RESOLUTION_ADMIN"),
} as const;
const distinctAuthorities = new Set(
  [initialAdmin, finalAdmin, ...Object.values(roleAddresses)].map((address) =>
    address.toLowerCase(),
  ),
);
if (distinctAuthorities.size !== 6) {
  throw new Error(
    "Temporary admin, final admin, and all four operational role addresses must be distinct",
  );
}

const deployments: Record<string, DeploymentRecord> = {};

const deploy = async (
  contractName: string,
  abi: Abi,
  bytecode: Hex,
  args: readonly unknown[] = [],
): Promise<Address> => {
  const hash = await walletClient.deployContract({
    abi,
    account,
    args,
    bytecode,
    chain,
  } as never);
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  if (receipt.status !== "success" || !receipt.contractAddress) {
    throw new Error(`${contractName} deployment failed: ${hash}`);
  }
  const address = getAddress(receipt.contractAddress);
  const installedBytecode = await publicClient.getBytecode({ address });
  if (!installedBytecode || installedBytecode === "0x") {
    throw new Error(`${contractName} has no installed bytecode at ${address}`);
  }
  deployments[contractName] = {
    address,
    blockNumber: receipt.blockNumber.toString(),
    bytecodeHash: keccak256(installedBytecode),
    transactionHash: hash,
  };
  return address;
};

const deployFoundry = async (
  contractName: string,
  args: readonly unknown[] = [],
): Promise<Address> => {
  const artifact = await loadArtifact(contractName);
  return deploy(contractName, artifact.abi, artifact.bytecode.object, args);
};

let conditionalTokens: Address;
if (Bun.env.DEPLOY_CONDITIONAL_TOKENS === "true") {
  const artifact = await loadConditionalTokensArtifact();
  conditionalTokens = await deploy("ConditionalTokens", artifact.abi, artifact.bytecode, []);
} else {
  conditionalTokens = environmentAddress("CONDITIONAL_TOKENS_ADDRESS");
  await assertContract(publicClient, conditionalTokens, "ConditionalTokens");
  const deployedBytecode = await publicClient.getBytecode({ address: conditionalTokens });
  deployments.ConditionalTokens = {
    address: conditionalTokens,
    ...(deployedBytecode ? { bytecodeHash: keccak256(deployedBytecode) } : {}),
  };
}

const usdg = environmentAddress("USDG_ADDRESS");
await assertContract(publicClient, usdg, "USDG");

const authority = await deployFoundry("ProtocolAuthority", [
  initialAdmin,
  roleAddresses.marketAdmin,
  roleAddresses.matcher,
  roleAddresses.guardian,
  roleAddresses.resolutionAdmin,
]);
const registry = await deployFoundry("MarketRegistry", [conditionalTokens, authority, usdg]);
const resolutionController = await deployFoundry("ManualResolutionController", [
  conditionalTokens,
  registry,
  authority,
]);
const exchange = await deployFoundry("ConditionalExchange", [
  conditionalTokens,
  registry,
  authority,
]);
const orderValidator = await deployFoundry("OrderValidator", [exchange]);
const settlement = await deployFoundry("ConditionalSettlement", [
  conditionalTokens,
  registry,
  exchange,
]);
const iocRouter = await deployFoundry("IOCRouter", [exchange, authority]);
await deployFoundry("OrderRecoveryRouter", [exchange]);
await deployFoundry("PositionRouter", [conditionalTokens]);

const registryArtifact = await loadArtifact("MarketRegistry");
const exchangeArtifact = await loadArtifact("ConditionalExchange");
const authorityArtifact = await loadArtifact("ProtocolAuthority");
const configure = async (
  label: string,
  address: Address,
  abi: Abi,
  functionName: string,
  args: readonly unknown[],
): Promise<Hash> => {
  const hash = await walletClient.writeContract({
    abi,
    account,
    address,
    args,
    chain,
    functionName,
  } as never);
  const receipt = await publicClient.waitForTransactionReceipt({ hash });
  if (receipt.status !== "success") throw new Error(`${label} failed: ${hash}`);
  return hash;
};

await configure(
  "setResolutionController",
  registry,
  registryArtifact.abi,
  "setResolutionController",
  [resolutionController],
);
await configure(
  "configureOrderValidator",
  exchange,
  exchangeArtifact.abi,
  "configureOrderValidator",
  [orderValidator],
);
await configure("configureSettlement", exchange, exchangeArtifact.abi, "configureSettlement", [
  settlement,
]);
await configure("configureIocRouter", exchange, exchangeArtifact.abi, "configureIocRouter", [
  iocRouter,
]);
const adminTransferTransactionHash = await configure(
  "beginDefaultAdminTransfer",
  authority,
  authorityArtifact.abi,
  "beginDefaultAdminTransfer",
  [finalAdmin],
);
const [pendingDefaultAdmin, pendingDefaultAdminAcceptAfter] = (await publicClient.readContract({
  abi: authorityArtifact.abi,
  address: authority,
  functionName: "pendingDefaultAdmin",
})) as readonly [Address, bigint];
if (pendingDefaultAdmin !== finalAdmin || pendingDefaultAdminAcceptAfter === 0n) {
  throw new Error("Default-admin transfer was not scheduled correctly");
}

const latestBlock = (await publicClient.getBlock({ blockTag: "latest" })).number;
const manifest = {
  chainId,
  compiler: {
    bytecodeHash: "none",
    evmVersion: "paris",
    optimizerRuns: 7_500,
    solc: "0.8.30",
    viaIr: true,
  },
  deployedAtBlock: latestBlock.toString(),
  deployments,
  roles: {
    currentDefaultAdmin: initialAdmin,
    pendingDefaultAdmin: finalAdmin,
    pendingDefaultAdminAcceptAfter: pendingDefaultAdminAcceptAfter.toString(),
    pendingDefaultAdminTransferTransactionHash: adminTransferTransactionHash,
    ...roleAddresses,
  },
  rpcUrl: "redacted",
  usdg,
};
const outputDirectory = resolve(import.meta.dir, `../deployments/${chainId}`);
await mkdir(outputDirectory, { recursive: true });
await Bun.write(resolve(outputDirectory, "v1.json"), `${JSON.stringify(manifest, null, 2)}\n`);
writeOutput(manifest);
