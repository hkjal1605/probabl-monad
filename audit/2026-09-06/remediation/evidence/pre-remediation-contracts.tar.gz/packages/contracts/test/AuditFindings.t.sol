// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

import { ProtocolConstants } from "../src/libraries/ProtocolConstants.sol";
import {
    Branch,
    FundingKind,
    MarketConfig,
    MarketState,
    Order,
    Side,
    TimeInForce
} from "../src/types/ProtocolTypes.sol";
import { ProtocolFixture } from "./ProtocolFixture.sol";

contract RejectingClaimRecipient { }

/// @notice Minimal reproductions retained with the audit report. A passing test demonstrates
///         that the behavior described by the corresponding finding is reachable.
contract AuditFindingsTest is ProtocolFixture {
    function testFindingConditionPreparationCanFrontRunMarketCreation() public {
        string memory uri = "ipfs://conditional-stocks/front-run-target";
        MarketConfig memory config = _config(uri, 500e18, 500e18, 1_000e18);
        bytes32 targetMarketId = registry.computeMarketId(config);
        bytes32 targetQuestionId = keccak256(abi.encode("CONDITIONAL_STOCKS_V1", targetMarketId));

        vm.prank(address(0xBEEF));
        ctf.prepareCondition(address(resolutionController), targetQuestionId, 2);

        vm.expectRevert();
        registry.createMarket(config, uri);
    }

    function testFindingResolutionAcceptsDifferentEvidenceHashThanPrepared() public {
        bytes32 preparedHash = keccak256("APPROVED_PACKET");
        bytes32 substitutedHash = keccak256("SUBSTITUTED_PACKET");
        registry.freezeMarket(marketId, keccak256("AUDIT_FREEZE"));
        registry.beginResolution(marketId, preparedHash);

        resolutionController.resolveMarket(
            marketId, 0, 1, 1, substitutedHash, "ipfs://substituted-packet"
        );

        assertTrue(preparedHash != substitutedHash, "test hashes must differ");
        assertEq(
            uint256(registry.marketState(marketId)),
            uint256(MarketState.REDEEMABLE),
            "substituted evidence finalized"
        );
    }

    function testFindingFilledExposureCanGrowBeyondMarketOpenNotionalCap() public {
        string memory uri = "ipfs://conditional-stocks/open-notional-only";
        MarketConfig memory config = _config(uri, 200e18, 400e18, 400e18);
        bytes32 cappedMarketId = registry.createMarket(config, uri);
        registry.openMarket(cappedMarketId);

        for (uint64 nonce = 200; nonce < 203; ++nonce) {
            Order memory bid = _order(
                buyer,
                Branch.YES,
                Side.BUY,
                FundingKind.WHOLE_COLLATERAL,
                1e18,
                200e18,
                TimeInForce.GTC,
                nonce,
                keccak256(abi.encode("CAP_BID", nonce))
            );
            Order memory ask = _order(
                seller,
                Branch.YES,
                Side.SELL,
                FundingKind.WHOLE_COLLATERAL,
                1e18,
                200e18,
                TimeInForce.GTC,
                nonce,
                keccak256(abi.encode("CAP_ASK", nonce))
            );
            bid.marketId = cappedMarketId;
            ask.marketId = cappedMarketId;

            exchange.openOrder(bid, _sign(bid, BUYER_KEY));
            exchange.openOrder(ask, _sign(ask, SELLER_KEY));
            exchange.matchOrders(bid, ask, 1e18);
            assertEq(exchange.marketOpenNotional(cappedMarketId), 0, "cap resets after fill");
        }

        assertEq(
            quote.balanceOf(address(ctf)),
            600e18,
            "locked quote collateral exceeds configured 400e18 market cap"
        );
    }

    function testFindingRejectingRecipientCreatesUnfillableTopOfBookOrder() public {
        RejectingClaimRecipient recipient = new RejectingClaimRecipient();
        Order memory bid = _order(
            buyer,
            Branch.YES,
            Side.BUY,
            FundingKind.WHOLE_COLLATERAL,
            1e18,
            210e18,
            TimeInForce.GTC,
            300,
            keccak256("REJECTING_RECIPIENT_BID")
        );
        bid.recipient = address(recipient);
        Order memory ask = _order(
            seller,
            Branch.YES,
            Side.SELL,
            FundingKind.WHOLE_COLLATERAL,
            1e18,
            200e18,
            TimeInForce.GTC,
            300,
            keccak256("REJECTING_RECIPIENT_ASK")
        );

        exchange.openOrder(bid, _sign(bid, BUYER_KEY));
        exchange.openOrder(ask, _sign(ask, SELLER_KEY));
        vm.expectRevert();
        exchange.matchOrders(bid, ask, 1e18);
    }

    function testFindingRegistryAcceptsCapsThatMakeMatchingImpossible() public {
        string memory uri = "ipfs://conditional-stocks/impossible-market-cap";
        MarketConfig memory config = _config(uri, 100e18, 100e18, 100e18);
        config.minNotional = 100e18;
        bytes32 impossibleMarketId = registry.createMarket(config, uri);
        registry.openMarket(impossibleMarketId);

        Order memory bid = _order(
            buyer,
            Branch.YES,
            Side.BUY,
            FundingKind.WHOLE_COLLATERAL,
            1e18,
            100e18,
            TimeInForce.GTC,
            400,
            keccak256("IMPOSSIBLE_CAP_BID")
        );
        Order memory ask = _order(
            seller,
            Branch.YES,
            Side.SELL,
            FundingKind.WHOLE_COLLATERAL,
            1e18,
            100e18,
            TimeInForce.GTC,
            400,
            keccak256("IMPOSSIBLE_CAP_ASK")
        );
        bid.marketId = impossibleMarketId;
        ask.marketId = impossibleMarketId;

        exchange.openOrder(bid, _sign(bid, BUYER_KEY));
        bytes memory askSignature = _sign(ask, SELLER_KEY);
        vm.expectRevert();
        exchange.openOrder(ask, askSignature);
    }

    function testFindingRegistryAcceptsTickAboveEveryPermittedOrderNotional() public {
        string memory uri = "ipfs://conditional-stocks/impossible-price-tick";
        MarketConfig memory config = _config(uri, 100e18, 100e18, 200e18);
        config.priceTickX18 = 101e18;
        bytes32 impossibleMarketId = registry.createMarket(config, uri);
        registry.openMarket(impossibleMarketId);

        Order memory order = _order(
            buyer,
            Branch.YES,
            Side.BUY,
            FundingKind.WHOLE_COLLATERAL,
            1e18,
            101e18,
            TimeInForce.GTC,
            500,
            keccak256("IMPOSSIBLE_TICK_ORDER")
        );
        order.marketId = impossibleMarketId;
        bytes memory signature = _sign(order, BUYER_KEY);

        vm.expectRevert();
        exchange.openOrder(order, signature);
    }

    function _config(
        string memory uri,
        uint128 maxOrderNotional,
        uint128 maxWalletOpenNotional,
        uint128 maxMarketOpenNotional
    ) private view returns (MarketConfig memory) {
        return MarketConfig({
            baseToken: address(stock),
            quoteToken: address(quote),
            polymarketConditionId: keccak256(abi.encode("AUDIT_EVENT", uri)),
            polymarketYesIndex: ProtocolConstants.YES_INDEX_SET,
            polymarketNoIndex: ProtocolConstants.NO_INDEX_SET,
            tradingOpen: uint64(block.timestamp),
            tradingCutoff: cutoff,
            rulesHash: keccak256(abi.encode("AUDIT_RULES", uri)),
            metadataHash: keccak256(bytes(uri)),
            priceTickX18: uint128(1e18),
            baseStep: uint128(1e18),
            minNotional: uint128(1e18),
            maxOrderQuantity: uint128(1e18),
            maxOrderNotional: maxOrderNotional,
            maxWalletOpenNotional: maxWalletOpenNotional,
            maxMarketOpenNotional: maxMarketOpenNotional
        });
    }
}
