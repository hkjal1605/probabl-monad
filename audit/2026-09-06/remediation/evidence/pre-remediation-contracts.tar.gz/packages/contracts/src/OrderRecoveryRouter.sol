// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

import { IOrderRecoveryExchange } from "./interfaces/IOrderRecoveryExchange.sol";

/// @notice Permissionless bounded best-effort batches for returning stale order escrow to makers.
contract OrderRecoveryRouter {
    error InvalidAddress();
    error InvalidBatchLength();

    enum ReleaseKind {
        EXPIRED,
        NONCE_INVALIDATED,
        MARKET_CLOSED
    }

    event OrderReleaseAttempt(
        bytes32 indexed orderHash, ReleaseKind indexed kind, bool success, bytes32 failureDataHash
    );

    uint256 public constant MAX_BATCH_LENGTH = 64;

    IOrderRecoveryExchange public immutable exchange;

    constructor(
        IOrderRecoveryExchange exchange_
    ) {
        if (address(exchange_) == address(0) || address(exchange_).code.length == 0) {
            revert InvalidAddress();
        }
        exchange = exchange_;
    }

    function releaseExpired(
        bytes32[] calldata orderHashes
    ) external {
        _validateLength(orderHashes.length);
        for (uint256 i; i < orderHashes.length; ++i) {
            bytes32 orderHash = orderHashes[i];
            try exchange.releaseExpiredOrder(orderHash) {
                emit OrderReleaseAttempt(orderHash, ReleaseKind.EXPIRED, true, bytes32(0));
            } catch (bytes memory reason) {
                emit OrderReleaseAttempt(orderHash, ReleaseKind.EXPIRED, false, keccak256(reason));
            }
        }
    }

    function releaseInvalidated(
        bytes32[] calldata orderHashes
    ) external {
        _validateLength(orderHashes.length);
        for (uint256 i; i < orderHashes.length; ++i) {
            bytes32 orderHash = orderHashes[i];
            try exchange.releaseInvalidatedOrder(orderHash) {
                emit OrderReleaseAttempt(orderHash, ReleaseKind.NONCE_INVALIDATED, true, bytes32(0));
            } catch (bytes memory reason) {
                emit OrderReleaseAttempt(
                    orderHash, ReleaseKind.NONCE_INVALIDATED, false, keccak256(reason)
                );
            }
        }
    }

    function releaseClosedMarkets(
        bytes32[] calldata orderHashes
    ) external {
        _validateLength(orderHashes.length);
        for (uint256 i; i < orderHashes.length; ++i) {
            bytes32 orderHash = orderHashes[i];
            try exchange.releaseClosedMarketOrder(orderHash) {
                emit OrderReleaseAttempt(orderHash, ReleaseKind.MARKET_CLOSED, true, bytes32(0));
            } catch (bytes memory reason) {
                emit OrderReleaseAttempt(
                    orderHash, ReleaseKind.MARKET_CLOSED, false, keccak256(reason)
                );
            }
        }
    }

    function _validateLength(
        uint256 length
    ) private pure {
        if (length == 0 || length > MAX_BATCH_LENGTH) revert InvalidBatchLength();
    }
}
