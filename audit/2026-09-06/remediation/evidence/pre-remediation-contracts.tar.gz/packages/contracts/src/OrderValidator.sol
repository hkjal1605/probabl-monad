// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

import { IERC1271 } from "@openzeppelin/contracts/interfaces/IERC1271.sol";
import { ECDSA } from "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";

import { IOrderValidator } from "./interfaces/IOrderValidator.sol";
import { Order } from "./types/ProtocolTypes.sol";

/// @notice Computes and verifies the immutable v1 exchange EIP-712 order schema.
/// @dev The EIP-712 verifying contract is the exchange, not this stateless helper.
contract OrderValidator is IOrderValidator {
    error InvalidAddress();
    error InvalidSignature();

    bytes32 public constant DOMAIN_TYPEHASH = keccak256(
        "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
    );
    bytes32 public constant NAME_HASH = keccak256("ConditionalExchange");
    bytes32 public constant VERSION_HASH = keccak256("1");
    bytes32 public constant ORDER_TYPEHASH = keccak256(
        "Order(address maker,address recipient,bytes32 marketId,uint8 branch,uint8 side,uint8 fundingKind,uint128 quantity,uint128 limitPriceX18,uint8 tif,uint64 expiry,uint64 nonce,bytes32 salt)"
    );

    address public immutable override exchange;

    constructor(
        address exchange_
    ) {
        if (exchange_ == address(0) || exchange_.code.length == 0) revert InvalidAddress();
        exchange = exchange_;
    }

    function hashOrder(
        Order calldata order
    ) public view override returns (bytes32) {
        bytes32 structHash = keccak256(
            abi.encode(
                ORDER_TYPEHASH,
                order.maker,
                order.recipient,
                order.marketId,
                uint8(order.branch),
                uint8(order.side),
                uint8(order.fundingKind),
                order.quantity,
                order.limitPriceX18,
                uint8(order.tif),
                order.expiry,
                order.nonce,
                order.salt
            )
        );
        bytes32 domainSeparator = keccak256(
            abi.encode(DOMAIN_TYPEHASH, NAME_HASH, VERSION_HASH, block.chainid, exchange)
        );
        return keccak256(abi.encodePacked("\x19\x01", domainSeparator, structHash));
    }

    function validate(
        Order calldata order,
        bytes calldata signature
    ) external view override returns (bytes32 orderHash) {
        orderHash = hashOrder(order);
        if (order.maker.code.length == 0) {
            (address recovered, ECDSA.RecoverError error,) = ECDSA.tryRecover(orderHash, signature);
            if (error != ECDSA.RecoverError.NoError || recovered != order.maker) {
                revert InvalidSignature();
            }
        } else {
            (bool success, bytes memory result) = order.maker
                .staticcall(abi.encodeCall(IERC1271.isValidSignature, (orderHash, signature)));
            if (
                !success || result.length < 32
                    || abi.decode(result, (bytes32)) != bytes32(IERC1271.isValidSignature.selector)
            ) revert InvalidSignature();
        }
    }
}
