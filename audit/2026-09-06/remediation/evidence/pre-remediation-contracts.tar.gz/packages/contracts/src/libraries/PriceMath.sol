// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

import { Math } from "@openzeppelin/contracts/utils/math/Math.sol";

import { ProtocolConstants } from "./ProtocolConstants.sol";

library PriceMath {
    function quoteDown(
        uint256 quantity,
        uint256 priceX18
    ) internal pure returns (uint256) {
        return Math.mulDiv(quantity, priceX18, ProtocolConstants.WAD);
    }

    function quoteUp(
        uint256 quantity,
        uint256 priceX18
    ) internal pure returns (uint256) {
        return Math.mulDiv(quantity, priceX18, ProtocolConstants.WAD, Math.Rounding.Ceil);
    }
}
