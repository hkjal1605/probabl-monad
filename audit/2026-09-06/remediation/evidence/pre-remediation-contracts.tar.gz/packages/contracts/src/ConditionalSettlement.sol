// SPDX-License-Identifier: MIT
pragma solidity 0.8.30;

import { IERC20 } from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import { SafeERC20 } from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import { ReentrancyGuard } from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

import { IConditionalTokens } from "./interfaces/IConditionalTokens.sol";
import { IMarketRegistry } from "./interfaces/IMarketRegistry.sol";
import { ProtocolConstants } from "./libraries/ProtocolConstants.sol";
import {
    Branch,
    FundingKind,
    Market,
    MarketState,
    SettlementFill
} from "./types/ProtocolTypes.sol";
import { ExpectedCtfReceiver } from "./utils/ExpectedCtfReceiver.sol";

/// @notice Atomically materializes and delivers fills already authorized by the exchange.
/// @dev This contract has no admin, upgrade, recovery, or arbitrary transfer function. Its
///      immutable exchange is the only caller and the only address from which it can pull assets.
contract ConditionalSettlement is ExpectedCtfReceiver, ReentrancyGuard {
    using SafeERC20 for IERC20;

    error FeeOnTransferUnsupported(address token);
    error InvalidAddress();
    error InvalidFill();
    error MarketNotOpen(bytes32 marketId);
    error OnlyExchange(address caller);
    error ResidualSettlementBalance(address asset, uint256 id, uint256 amount);

    event CollateralSplit(
        bytes32 indexed marketId,
        address indexed funder,
        address indexed collateralToken,
        bytes32 conditionId,
        uint256 amount
    );

    IMarketRegistry public immutable registry;
    address public immutable exchange;

    modifier onlyExchange() {
        if (msg.sender != exchange) revert OnlyExchange(msg.sender);
        _;
    }

    constructor(
        IConditionalTokens conditionalTokens_,
        IMarketRegistry registry_,
        address exchange_
    ) ExpectedCtfReceiver(conditionalTokens_) {
        if (
            address(registry_) == address(0) || address(registry_).code.length == 0
                || exchange_ == address(0) || exchange_.code.length == 0
        ) revert InvalidAddress();
        if (address(registry_.ctf()) != address(conditionalTokens_)) revert InvalidAddress();
        registry = registry_;
        exchange = exchange_;
    }

    function settleFill(
        SettlementFill calldata fill
    ) external nonReentrant onlyExchange {
        if (
            fill.buyerMaker == address(0) || fill.buyerRecipient == address(0)
                || fill.sellerMaker == address(0) || fill.sellerRecipient == address(0)
                || fill.fillQuantity == 0 || fill.executionQuote == 0
        ) revert InvalidFill();

        Market memory market = registry.getMarket(fill.marketId);
        if (
            market.state != MarketState.OPEN || block.timestamp < market.tradingOpen
                || block.timestamp >= market.tradingCutoff
        ) revert MarketNotOpen(fill.marketId);

        _settleStock(fill, market);
        _settleQuote(fill, market);
    }

    function _settleStock(
        SettlementFill calldata fill,
        Market memory market
    ) private {
        uint256 activePosition =
            fill.branch == Branch.YES ? market.stockYesPositionId : market.stockNoPositionId;

        if (fill.sellFundingKind == FundingKind.WHOLE_COLLATERAL) {
            uint256 inactivePosition =
                fill.branch == Branch.YES ? market.stockNoPositionId : market.stockYesPositionId;
            uint256 balanceBefore = _pullWhole(IERC20(market.baseToken), fill.fillQuantity);
            _splitCollateral(
                fill.marketId,
                fill.sellerMaker,
                IERC20(market.baseToken),
                market.conditionId,
                market.stockYesPositionId,
                market.stockNoPositionId,
                fill.fillQuantity,
                balanceBefore
            );
            conditionalTokens.safeTransferFrom(
                address(this), fill.buyerRecipient, activePosition, fill.fillQuantity, ""
            );
            conditionalTokens.safeTransferFrom(
                address(this), fill.sellerMaker, inactivePosition, fill.fillQuantity, ""
            );
            _assertNoClaimBalance(inactivePosition);
        } else {
            _pullClaim(activePosition, fill.fillQuantity);
            conditionalTokens.safeTransferFrom(
                address(this), fill.buyerRecipient, activePosition, fill.fillQuantity, ""
            );
        }

        _assertNoClaimBalance(activePosition);
    }

    function _settleQuote(
        SettlementFill calldata fill,
        Market memory market
    ) private {
        uint256 activePosition =
            fill.branch == Branch.YES ? market.quoteYesPositionId : market.quoteNoPositionId;

        if (fill.buyFundingKind == FundingKind.WHOLE_COLLATERAL) {
            uint256 inactivePosition =
                fill.branch == Branch.YES ? market.quoteNoPositionId : market.quoteYesPositionId;
            uint256 balanceBefore = _pullWhole(IERC20(market.quoteToken), fill.executionQuote);
            _splitCollateral(
                fill.marketId,
                fill.buyerMaker,
                IERC20(market.quoteToken),
                market.conditionId,
                market.quoteYesPositionId,
                market.quoteNoPositionId,
                fill.executionQuote,
                balanceBefore
            );
            conditionalTokens.safeTransferFrom(
                address(this), fill.sellerRecipient, activePosition, fill.executionQuote, ""
            );
            conditionalTokens.safeTransferFrom(
                address(this), fill.buyerMaker, inactivePosition, fill.executionQuote, ""
            );
            _assertNoClaimBalance(inactivePosition);
        } else {
            _pullClaim(activePosition, fill.executionQuote);
            conditionalTokens.safeTransferFrom(
                address(this), fill.sellerRecipient, activePosition, fill.executionQuote, ""
            );
        }

        _assertNoClaimBalance(activePosition);
    }

    function _pullWhole(
        IERC20 token,
        uint256 amount
    ) private returns (uint256 balanceBefore) {
        balanceBefore = token.balanceOf(address(this));
        token.safeTransferFrom(exchange, address(this), amount);
        if (token.balanceOf(address(this)) - balanceBefore != amount) {
            revert FeeOnTransferUnsupported(address(token));
        }
    }

    function _pullClaim(
        uint256 positionId,
        uint256 amount
    ) private {
        _expectSingle(address(this), exchange, positionId, amount);
        conditionalTokens.safeTransferFrom(exchange, address(this), positionId, amount, "");
        _assertExpectedTransferReceived();
    }

    function _splitCollateral(
        bytes32 marketId,
        address funder,
        IERC20 collateralToken,
        bytes32 conditionId,
        uint256 yesPositionId,
        uint256 noPositionId,
        uint256 amount,
        uint256 expectedBalance
    ) private {
        collateralToken.forceApprove(address(conditionalTokens), amount);

        uint256[] memory partition = new uint256[](2);
        partition[0] = ProtocolConstants.YES_INDEX_SET;
        partition[1] = ProtocolConstants.NO_INDEX_SET;
        uint256[] memory positionIds = new uint256[](2);
        positionIds[0] = yesPositionId;
        positionIds[1] = noPositionId;
        uint256[] memory amounts = new uint256[](2);
        amounts[0] = amount;
        amounts[1] = amount;

        _expectBatch(address(this), address(0), positionIds, amounts);
        conditionalTokens.splitPosition(
            collateralToken, ProtocolConstants.PARENT_COLLECTION_ID, conditionId, partition, amount
        );
        _assertExpectedTransferReceived();
        collateralToken.forceApprove(address(conditionalTokens), 0);
        uint256 actualBalance = collateralToken.balanceOf(address(this));
        if (actualBalance != expectedBalance) {
            revert ResidualSettlementBalance(address(collateralToken), 0, actualBalance);
        }
        emit CollateralSplit(marketId, funder, address(collateralToken), conditionId, amount);
    }

    function _assertNoClaimBalance(
        uint256 positionId
    ) private view {
        uint256 balance = conditionalTokens.balanceOf(address(this), positionId);
        if (balance != 0) {
            revert ResidualSettlementBalance(address(conditionalTokens), positionId, balance);
        }
    }
}
